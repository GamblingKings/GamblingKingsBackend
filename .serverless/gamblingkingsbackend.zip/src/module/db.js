"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var AWS = require("aws-sdk");
var db = new AWS.DynamoDB.DocumentClient({ apiVersion: "2012-08-10" });
exports.default = db;
//# sourceMappingURL=db.js.map